const scrollDownbtn = document.querySelector(".scroll-down");
const section2 = document.querySelector(".section-2");
const cryptoPrices = document.querySelector(".list-group");

scrollDownbtn.addEventListener("click", function (e) {
  e.preventDefault();
  section2.scrollIntoView({ behavior: "smooth" });
});

[...cryptoPrices.children].forEach((crypto) => {
  const cryptoPnl = crypto.querySelector(".pnl");
  // console.log(cryptoPnl.textContent);

  if (cryptoPnl.textContent.includes("+")) {
    cryptoPnl.classList.add("text-success");
  } else if (cryptoPnl.textContent.includes("-")) {
    cryptoPnl.classList.add("text-danger");
  } else {
    cryptoPnl.classList.add("text-dark");
  }
  // console.log(crypto.classList);
});

// import { get } from "axios";

// let response = null;
// new Promise(async (resolve, reject) => {
//   try {
//     response = await get(
//       "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest",
//       {
//         headers: {
//           "X-CMC_PRO_API_KEY": "9989e18f-989b-4c70-a60a-3b0f045afa61",
//         },
//       }
//     );
//   } catch (ex) {
//     response = null;
//     // error
//     console.log(ex);
//     reject(ex);
//   }
//   if (response) {
//     // success
//     const json = response.data;
//     console.log(json);
//     resolve(json);
//   }
// });
